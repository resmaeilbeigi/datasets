This is a set of randomly generated data for a stochastic capacitated hierarchical facility location problem with two types of facilities: collection centers and plants.

There are 6 folders: "N=5", ..., "N=50" where N denotes the number of demand points. Each folder contains 100 instances of the problem.

In each instance:
*******************************************
*******************************************
1. Non-numeric information starts with < and ends with >
2. (x,y) denotes the coordinate of a demand point on the plane.
3. outsourcing price denotes the unit outsourcing price of demand
4. scenario matrix is an N by 1000 matrix, where 1000 is the total number of scenarios. To solve the problem with M number of scenarios, we select the first M scenarios from this matrix.
5. All other parameters are self-explanatory.
*******************************************
*******************************************


Further details regarding this data set can be found in the following paper:

Benders decomposition for a reverse logistics network design problem in the dairy industry ...