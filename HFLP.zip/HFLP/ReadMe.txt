This is a set of randomly generated data for a capacitated hierarchical facility location problem with two types of facilities: collection centers and plants.

Non-numeric information starts with < and ends with >

In this data set, (x,y) denotes the coordinate of a demand point on the plane. All other parameters are self-explanatory.

Further details regarding this data set can be found in the following paper:

Benders decomposition for a reverse logistics network design problem in the dairy industry ...